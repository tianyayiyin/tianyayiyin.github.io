@echo off
setlocal
title C Drive Rescue
cd /d "%~dp0"

echo.
echo ==========================================
echo   C Drive Rescue / C盘急救箱
echo ==========================================
echo.
echo 1. Scan only / 只扫描生成报告
echo 2. Scan + safe cleanup / 扫描并安全清理临时缓存
echo.
set /p choice=Choose 1 or 2, then press Enter: 

if "%choice%"=="2" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0cdrive-rescue.ps1" -CleanSafe
) else (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0cdrive-rescue.ps1"
)

echo.
echo Done. The report is on your Desktop in CDriveRescue_Report.
echo 完成。报告在桌面的 CDriveRescue_Report 文件夹。
echo.
pause
